var taskslist = {
    tasks : [] ,
    addTasks : function(taskElement,dateElement){
        this.tasks.push({
            name: taskElement.value,
            date: dateElement.value,
            status: false
        });
        view.displayTasks();
    },
    
    deleteByIndex : function (index){
        console.log(index);
        taskslist.tasks.splice(index,1);
        console.log(taskslist.tasks[index]);
    },
     
    changeStatusByIndex : function (index){
        console.log(index);
        taskslist.tasks[index].status = !taskslist.tasks[index].status;
        console.log(taskslist.tasks[index]);
    
    }
    
    
}

var handler = {
    
    add : function (){
        var taskElement = document.getElementById("taskname");
        var dateElement = document.getElementById("taskdate");
        if(taskElement.value === "" || dateElement.value === ""){
            alert("Task can not be empty ")
        }
        else{
        taskslist.addTasks(taskElement,dateElement);
        }
    },
    
    delete : function () {
     var checkboxes = document.getElementsByName("chkbx");
     for (index = checkboxes.length-1 ; index > -1 ; index--){
         if(checkboxes[index].checked){
            taskslist.deleteByIndex(index);
         }}
        view.displayTasks();
    },
    
    
    
    changeStatus : function (){
    var checkboxes = document.getElementsByName("chkbx");
     for (index = 0 ; index<checkboxes.length ; index ++){
         if(checkboxes[index].checked){
            taskslist.changeStatusByIndex(index);
         }}
        view.displayTasks();
    },
    
    
    multiSelect: function (){
        var checkboxes = document.getElementsByName("chkbx");
        var checkboxes = document.getElementById("multipleSelect");
       
        for (index = checkboxes.length-1 ; index > -1 ; index--){
          
                checkboxes[index].checked = false;
            }
            
        }
    }
    
    
    
}

var view = {
    displayTasks : function (){
        var viewElement =  document.getElementById("tasksview");
        viewElement.innerHTML="";
        viewElement = this.createTableHeader(viewElement);
        var index=0;
        var taskArray = taskslist.tasks;
      
        for(index=0;index<taskArray.length;index++){
            var tr = document.createElement("tr");
            var checkbox = view.createCheckBox();
            checkbox.setAttribute("id",index);
            checkbox.setAttribute("name","chkbx");
            
            console.log(checkbox);
            var checkBoxElement = document.createElement("td");
            checkBoxElement.appendChild(checkbox);
            var titleElement = document.createElement("td");
            titleElement.append(taskArray[index].name);
            var dateElement = document.createElement("td");
            dateElement.append(taskArray[index].date);
            var statusElement = document.createElement("td");
            statusElement.append(taskArray[index].status);
            tr.appendChild(checkBoxElement);
            tr.appendChild(titleElement);
            tr.appendChild(dateElement);
            tr.appendChild(statusElement);
            viewElement.appendChild(tr);
        }      
        console.log(viewElement)
    },
    
    createTableHeader : function (viewElement){
        var tableHeader = document.createElement("tr");
        var checkbox = view.createCheckBox();
        checkbox.setAttribute("id","multipleSelect");
        checkbox.setAttribute("onclick","handler.multiSelect()");
        var checkBoxElement = document.createElement("td");
        checkBoxElement.appendChild(checkbox);
        var titleElement = document.createElement("td");
        titleElement.append("TITLE");
        var dateElement = document.createElement("td");
        dateElement.append("DUE DATE");
        var statusElement = document.createElement("td");
        statusElement.append("STATUS");
        tableHeader.appendChild(checkBoxElement);
        tableHeader.appendChild(titleElement);
        tableHeader.appendChild(dateElement);
        tableHeader.appendChild(statusElement);        
        viewElement.appendChild(tableHeader);
        return viewElement;
    },
    
    createCheckBox : function (){
    var checkBoxElement = document.createElement("input");
    checkBoxElement.type="checkbox";
    return checkBoxElement;
    }
}
